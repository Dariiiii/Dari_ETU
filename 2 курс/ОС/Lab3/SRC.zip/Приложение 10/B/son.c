#include <stdio.h>
int main()
{
    printf("SON PARAMS: pid=%i ppid=%i\n", getpid(), getppid());
    return 0;
}
